var carouselTemplate = $.templates(
	'<div class="item">\
		<a href="{{:url}}" class="credits">\
			<img src="{{:picUrl}}" class="carousel-image" />\
		</a>\
	</div>'
);