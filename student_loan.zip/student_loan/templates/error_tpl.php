<section class="error-message-area">
  <div class="image <?= $error_type ?>"></div>
  <div class="content"><?= $title ?></div>
</section>
